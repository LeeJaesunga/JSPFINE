document.addEventListener("DOMContentLoaded", function() {
   const checkinBtn = document.getElementById('checkin_btn');
   const checkoutBtn = document.getElementById('checkout_btn');
   const checkinCalendar = document.getElementById('checkin_calendar');
   const checkinDateDisplay = document.querySelector('.check_in_date');
   const checkoutDateDisplay = document.querySelector('.check_out_date');
   const hiddenCheckinDate = document.getElementById('hidden_checkin_date');
   const hiddenCheckoutDate = document.getElementById('hidden_checkout_date');

   const dateOptions = {
      dateFormat: "Y-m-d",
      mode: "range",
      minDate: "today",
      onChange: function(selectedDates, dateStr, instance) {
         const [checkinDate, checkoutDate] = selectedDates;
         if (checkinDate && checkoutDate) {
            const startDateStr = dateStr.split(" to ")[0];
            const endDateStr = dateStr.split(" to ")[1];

            checkinDateDisplay.textContent = startDateStr;
            checkoutDateDisplay.textContent = endDateStr;

            hiddenCheckinDate.value = startDateStr;
            hiddenCheckoutDate.value = endDateStr;
         }
      }
   };

   // flatpickr를 사용하여 캘린더 설정
   flatpickr(checkinCalendar, dateOptions);
});

// 투숙객 버튼을 클릭하면 투숙객 선택 모달을 표시합니다.
const guestBtn = document.querySelector('.guest_btn');
guestBtn.addEventListener('click', function() {
   $('#guestModal').modal('show');
});

// 투숙객 선택 모달에서 저장 버튼을 클릭하면 선택된 인원을 표시합니다.
const guestModalSaveBtn = document.getElementById('guestModalSave');
guestModalSaveBtn.addEventListener('click', function() {
   const adultCount = document.getElementById('adultCount').value;
   const childCount = document.getElementById('childCount').value;
   const total = parseInt(adultCount) + parseInt(childCount)
   const resPeo = document.querySelector('.res_peo');
   resPeo.innerHTML = `<span class="adult_input">성인: ${adultCount} 명</span>, <span class="child_input">어린이: ${childCount} 명</span> -> 총: <span class="total_input">${total}</span> 명`;
   $('#guestModal').modal('hide');
});

$(function() {

   /*$('#reservation_btn').click(function()  {
      // 성인 수를 HTML 요소에서 가져옵니다.
      
      
      var start_date = $('.check_in_date').text();
      var end_date = $('.check_out_date').text();
      var total = $('#total_input').value;
      var adultCount = $('#adult_input').value;
      var childrenCount = $('#child_input').value;
      
      var datas = { AdultCount: adultCount, ChildrenCount: childrenCount, StartDate: start_date, EndDate: end_date, Total: total };

      $.ajax({
         type: "POST",
         url: "room_changepick_reservation",
         data: JSON.stringify(datas), // 객체를 JSON 문자열로 변환하여 전송합니다.
         contentType: "application/json", // 데이터 타입을 JSON으로 설정합니다.
         error: function(xhr, status, error) {
            alert(error);
         }
      });
   });*/
});