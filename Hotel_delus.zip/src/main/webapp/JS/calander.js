  /* 달력에서 날짜를 선택하면 Check In과 Check Out 밑에 날짜가 반영되는 코드*/
 $(function() {
    $('input[name="datetimes"]').daterangepicker({
        timePicker: true,
        startDate: moment().startOf('hour'),
        endDate: moment().startOf('hour').add(32, 'hour'),
        minDate: moment().startOf('day'),  // 오늘 날짜 이후로만 선택 가능
        locale: {
            format: 'M/DD hh:mm A'
        }
    });

    $('input[name="datetimes"]').on('apply.daterangepicker', function(ev, picker) {
        let startDate = picker.startDate.format('YYYY-MM-DD');
        let endDate = picker.endDate.format('YYYY-MM-DD');
        
        // 날짜를 HTML 요소에 반영
        $('.start_date').text(startDate);
        $('.end_date').text(endDate);
        
        // Check Out의 위치를 변경하지 않음
        $('.end_date').css('left', $('.start_date').position().left); // Check Out의 위치를 Check In의 위치로 고정
    });
});

function showNumberSelect() {
    document.getElementById('numberSelect').style.display = 'block';
}

function closeNumberSelect() {
    document.getElementById('numberSelect').style.display = 'none';
}

function cancelSelection() {
    document.getElementById('numberSelect').style.display = 'none';
}
  
/* 성인, 어린이 인원 수 변경 */
 document.addEventListener("DOMContentLoaded", function() {
            // 성인 + 버튼 클릭 시
            document.querySelector('.adult_plus').addEventListener('click', function(event) {
                event.preventDefault();
                var adultSelect = document.querySelector('.adult_select');
                var currentAdultCount = parseInt(adultSelect.textContent);
                adultSelect.textContent = currentAdultCount + 1;
                // Adult 아래의 숫자 업데이트
                document.querySelector('.adult_input').textContent = adultSelect.textContent + "명";
            });

            // 성인 - 버튼 클릭 시
            document.querySelector('.adult_minus').addEventListener('click', function(event) {
                event.preventDefault();
                var adultSelect = document.querySelector('.adult_select');
                var currentAdultCount = parseInt(adultSelect.textContent);
                if (currentAdultCount > 1) {
                    adultSelect.textContent = currentAdultCount - 1;
                    // Adult 아래의 숫자 업데이트
                    document.querySelector('.adult_input').textContent = adultSelect.textContent + "명";
                }
            });

            // 어린이 + 버튼 클릭 시
            document.querySelector('.children_plus').addEventListener('click', function(event) {
                event.preventDefault();
                var childrenSelect = document.querySelector('.children_select');
                var currentChildrenCount = parseInt(childrenSelect.textContent);
                childrenSelect.textContent = currentChildrenCount + 1;
                // Children 아래의 숫자 업데이트
                document.querySelector('.children_input').textContent = childrenSelect.textContent + "명";
            });

            // 어린이 - 버튼 클릭 시
            document.querySelector('.children_minus').addEventListener('click', function(event) {
                event.preventDefault();
                var childrenSelect = document.querySelector('.children_select');
                var currentChildrenCount = parseInt(childrenSelect.textContent);
                if (currentChildrenCount > 0) {
                    childrenSelect.textContent = currentChildrenCount - 1;
                    // Children 아래의 숫자 업데이트
                    document.querySelector('.children_input').textContent = childrenSelect.textContent + "명";
                }
            });
        });

         function cancelSelection() {
            // 어른과 아이의 선택된 숫자를 0으로 설정
            document.querySelector('.adult_select').textContent = '0';
            document.querySelector('.children_select').textContent = '0';
            // 선택된 숫자를 HTML 요소에 반영
            document.querySelector('.adult_input').textContent = '0명';
            document.querySelector('.children_input').textContent = '0명';
        }

        function closeNumberSelect() {
            // number_select 창 닫기
            var numberSelect = document.getElementById('numberSelect');
            numberSelect.style.display = 'none';
        }