
function handleMouseOver(element) {
    // 해당 li 요소의 다음 형제 요소인 hr 요소를 선택하여 너비를 100%로 변경
    $(element).next('.mypage_li_text_hr').css('width', '77%' ,500);
}

function handleMouseLeave(element) {
    // 해당 li 요소의 다음 형제 요소인 hr 요소의 너비를 0%로 변경
    $(element).next('.mypage_li_text_hr').css('width', '0%', 500);
}
