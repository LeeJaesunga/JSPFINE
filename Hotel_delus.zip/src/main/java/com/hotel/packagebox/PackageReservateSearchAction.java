package com.hotel.packagebox;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.PackageReservateDTO;

public class PackageReservateSearchAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		  
		  int totalRecord = 0;
	      int rowsize = 10;
	      int block = 3;
	      int allPage = 0;
	      int page = 1;
	      
	      if (request.getParameter("page") != null) {
		         page = Integer.parseInt(request.getParameter("page").trim());
		         if (page < 1) {
		            page = 1;
		         }
		      }
	      
	      int startNo = (page * rowsize) - (rowsize - 1);
	      int endNo = (page * rowsize);
	      int startBlock = (((page - 1) / block) * block) + 1;
	      int endBlock = (((page - 1) / block) * block) + block;
				
	      String field = request.getParameter("field").trim();
	      String keyword = request.getParameter("keyword").trim();
	      
	      totalRecord = dao.PackageReservateListSearchCount(field, keyword);
	      
	      allPage = (int) Math.ceil(totalRecord / (double) rowsize);
		
	      if (endBlock > allPage) {
		         endBlock = allPage;
		      }

	      boolean is_Search = true;    
		      
		  List<PackageReservateDTO> list = dao.PackageReservateSearch(field, keyword, page, rowsize);
		  
		  request.setAttribute("list", list);
	      request.setAttribute("totalRecord", totalRecord);
	      request.setAttribute("page", page);
	      request.setAttribute("rowsize", rowsize);
	      request.setAttribute("block", block);
	      request.setAttribute("allPage", allPage);
	      request.setAttribute("startNo", startNo);
	      request.setAttribute("endNo", endNo);
	      request.setAttribute("startBlock", startBlock);
	      request.setAttribute("endBlock", endBlock);
	      request.setAttribute("field", field);
	      request.setAttribute("keyword", keyword);
	      request.setAttribute("is_Search", is_Search);
	      
	      

	      ActionForward forward = new ActionForward();

	      forward.setPath("/WEB-INF/views/mypage/review/room_inquiry_list.jsp");

	      return forward;
	}

}
