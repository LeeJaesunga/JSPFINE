package com.hotel.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;

public class UserIdCheckAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String userid = request.getParameter("paramId").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int res = dao.checkUserId(userid); 
		
		PrintWriter out = response.getWriter();
		
		out.println(res);
		
		
		return null;
	}

}
