package com.hotel.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;

public class UserJoinOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		String name = request.getParameter("name");
		String id = request.getParameter("id");
		String pwd = request.getParameter("pwd");
		String email = request.getParameter("email");
		String phone1 = request.getParameter("phone1");
		String phone2 = request.getParameter("phone2");
		String phone3 = request.getParameter("phone3");
		
		String phone = phone1 + "-" + phone2 + "-" + phone3;
		
		HotelUserDTO dto = new HotelUserDTO();
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		Calendar c1 = Calendar.getInstance();
		String date = sdf.format(c1.getTime());
		
		dto.setHotel_user_no("HU" + date);
		dto.setHotel_user_name(name);
		dto.setHotel_user_id(id);
		dto.setHotel_user_pwd(pwd);
		dto.setHotel_user_email(email);
		dto.setHotel_user_phone(phone);
		
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.insertHotelUser(dto);
		
		PrintWriter out = response.getWriter();
		
		if (check > 0) {
			request.setAttribute("name", name);
			ActionForward forward = new ActionForward();
			
			forward.setPath("/WEB-INF/views/join/join_ok.jsp");
			
			return forward;
			
		} else {
			out.println("<script>");
			out.println("alert('회원가입에 실패했습니다. 입력한 정보를 다시 한번 확인해주세요.')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		
		
		return null;
	}

}
