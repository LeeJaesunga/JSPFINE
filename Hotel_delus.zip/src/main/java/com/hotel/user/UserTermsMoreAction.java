package com.hotel.user;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;

public class UserTermsMoreAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int no = Integer.parseInt(request.getParameter("no").trim());
		
		ActionForward forward = new ActionForward();

		if(no == 1) {
			forward.setPath("/WEB-INF/views/join/window/window1.jsp");
		} else if(no == 2) {
			forward.setPath("/WEB-INF/views/join/window/window2.jsp");
		} else if(no == 3) {
			forward.setPath("/WEB-INF/views/join/window/window3.jsp");
		} else if(no == 4) {
			forward.setPath("/WEB-INF/views/join/window/window4.jsp");
		} else if(no == 5) {
			forward.setPath("/WEB-INF/views/join/window/window5.jsp");
		} else if(no == 6) {
			forward.setPath("/WEB-INF/views/join/window/window6.jsp");
		} else if(no == 7) {
			forward.setPath("/WEB-INF/views/join/window/window7.jsp");
		}
		
		return forward;
	}

}
