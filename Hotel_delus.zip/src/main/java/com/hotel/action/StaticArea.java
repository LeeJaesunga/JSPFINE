package com.hotel.action;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.model.AdminDTO;
import com.hotel.model.HotelUserDTO;

public class StaticArea {

	// jsp 파일에서 반복적으로 사용될 리스트
	

	
	
	
	
	
	public static void checkUserDTO(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

			HotelUserDTO dto = (HotelUserDTO) session.getAttribute("dto");

		if (dto == null) {

			session.invalidate();
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('세션이 종료되었습니다. 다시 로그인 해주세요.')");
			out.println("location.href='main'");
			out.println("</script>");
			out.close();

		}

	}

	public static void checkAdminDTO(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		AdminDTO a_cont = (AdminDTO) session.getAttribute("a_cont");

		if (a_cont == null) {

			session.invalidate();
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('세션이 종료되었습니다. 다시 로그인 해주세요.')");
			out.println("location.href='main'");
			out.println("</script>");
			out.close();

		}

	}
	
	public static void adminLoginStatus(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();

		AdminDTO a_cont = (AdminDTO) session.getAttribute("a_cont");

		if (a_cont != null) {

			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('관리자로 로그인 했습니다!!!')");
			out.println("history.back()");
			out.println("</script>");
			out.close();

		}

	}
}