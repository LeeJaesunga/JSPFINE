package com.hotel.mypage.review;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomReviewDTO;

public class MypageReviewSearchContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String review_no =request.getParameter("no").trim();
		int page = Integer.parseInt(request.getParameter("page").trim());
		String field = request.getParameter("field").trim();
		String keyword = request.getParameter("keyword").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		RoomReviewDTO dto = dao.getSearchReviewContent(review_no); 
		
		request.setAttribute("dto", dto);
		request.setAttribute("page", page);
		request.setAttribute("field", field);
		request.setAttribute("keyword", keyword);
		
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/mypage/review/mypage_review_content.jsp");

		return forward;
	}

}
