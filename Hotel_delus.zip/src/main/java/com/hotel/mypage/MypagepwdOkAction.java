package com.hotel.mypage;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;

public class MypagepwdOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkUserDTO(request, response);
		
		HttpSession session = request.getSession();

	    HotelUserDTO cont = (HotelUserDTO) session.getAttribute("dto");
	    System.out.println("cont = " + cont);
	    
	    String user_id = cont.getHotel_user_id();
	    System.out.println("user_id = " + user_id);
	    
	    String user_pwd = cont.getHotel_user_pwd();
		System.out.println("user_pwd = " + user_pwd);
		
		String user_pwd1 = request.getParameter("pwd").trim();
		System.out.println("user_pwd1 = " + user_pwd1);

		HotelTotalDAO dao = HotelTotalDAO.getInstance();

		if(user_pwd.equals(user_pwd1)) {
			
			HotelUserDTO dto = dao.UserInfoModify(user_id);
			
			request.setAttribute("Mod", dto);
			
			ActionForward forward = new ActionForward();
			
			forward.setPath("/WEB-INF/views/mypage/info/user_info_modify.jsp");
				
			return forward;
		} else {
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('비밀번호를 확인해주세요')");
			out.println("history.back()");
			out.println("</script>");
			return null;
		}

	}

}
