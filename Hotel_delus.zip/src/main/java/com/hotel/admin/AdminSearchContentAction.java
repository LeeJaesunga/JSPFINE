package com.hotel.admin;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.AdminDTO;
import com.hotel.model.HotelTotalDAO;

public class AdminSearchContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);
		
		String admin_no = request.getParameter("no").trim();
		int page = Integer.parseInt(request.getParameter("page").trim());
		String field = request.getParameter("field").trim();
		String keyword = request.getParameter("keyword").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		AdminDTO dto = dao.getAdminContent(admin_no);
		
		request.setAttribute("dto", dto);
		request.setAttribute("page", page);
		request.setAttribute("field", field);
		request.setAttribute("keyword", keyword);
				
		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/adminster/admin_content.jsp");

		return forward;
	}

}
