package com.hotel.admin.user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;

public class AdminUserModifyOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);
		
		String user_name = request.getParameter("user_name").trim();
		String user_no = request.getParameter("user_no").trim();
		String user_id = request.getParameter("user_id").trim();
		String user_pwd = request.getParameter("user_pwd").trim();
		String user_phone = request.getParameter("user_phone").trim();
		String user_email = request.getParameter("user_email").trim();
		String user_rank = request.getParameter("user_rank").trim();
		String user_payment_info = request.getParameter("user_payment_info").trim();
		
		int nowPage = Integer.parseInt(request.getParameter("page").trim());
		
		HotelUserDTO dto = new HotelUserDTO();
		
		dto.setHotel_user_name(user_name);
		dto.setHotel_user_no(user_no);
		dto.setHotel_user_id(user_id);
		dto.setHotel_user_pwd(user_pwd);
		dto.setHotel_user_phone(user_phone);
		dto.setHotel_user_email(user_email);
		dto.setHotel_user_rank(user_rank);
		dto.setHotel_user_payment_info(user_payment_info);
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		int check = dao.AdminUserUpdate(dto);
		
		PrintWriter out = response.getWriter();
		
		if(check > 0) {
			out.println("<script>");
			out.println("alert('수정 성공')");
			out.println("location.href='admin_user_content?no="+user_no+"&page="+nowPage+"'");
			out.println("</script>");
		}else {
			out.println("<script>");
			out.println("alert('수정 실패')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		
		return null;
	}

}
