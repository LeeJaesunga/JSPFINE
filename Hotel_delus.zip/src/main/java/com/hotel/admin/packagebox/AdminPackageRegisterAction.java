package com.hotel.admin.packagebox;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;

public class AdminPackageRegisterAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);

		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/admin/package/admin_package_register.jsp");

		return forward;
		
	}

}
