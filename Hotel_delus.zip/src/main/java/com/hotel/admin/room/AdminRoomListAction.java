package com.hotel.admin.room;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomDTO;

public class AdminRoomListAction implements Action {

    @Override
    public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	StaticArea.checkAdminDTO(request, response);
    	
        HotelTotalDAO dao = HotelTotalDAO.getInstance();
        
        String room_type = request.getParameter("type").trim();
        
        System.out.println(room_type);
        
        int cnt = 0;
        int rowsize = 10;
        int block = 3;
        int allPage = 0;
        int page = 1;
        
        if(request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page").trim());
            if (page < 1) {
                page = 1;
            }
        }
        
		
		int startNo = (page * rowsize) - (rowsize - 1); 
		int endNo = (page * rowsize);
		
        int startBlock = (((page - 1) / block) * block) + 1;
        int endBlock = (((page - 1) / block) * block) + block;
        
        cnt = dao.getRoomCount(room_type); // room_type별로 방의 수를 가져오도록 수정
        
        allPage = (int) Math.ceil(cnt / (double) rowsize);
        
        if (endBlock > allPage) {
            endBlock = allPage;
        }
        
        List<RoomDTO> list = dao.getRoomList(room_type, page, rowsize); // 페이징 기능 추가
        String name = dao.getRoomName(room_type);
        
        request.setAttribute("list", list);
        request.setAttribute("name", name);
        request.setAttribute("page", page);
        request.setAttribute("rowsize", rowsize);
        request.setAttribute("allPage", allPage);
        request.setAttribute("startBlock", startBlock);
        request.setAttribute("endBlock", endBlock);
        request.setAttribute("type", room_type);
        request.setAttribute("startNo", startNo);
        request.setAttribute("endNo", endNo);
        
        ActionForward forward = new ActionForward();
        forward.setPath("/WEB-INF/views/admin/room/admin_room_list.jsp");
        
        return forward;
    }
}
