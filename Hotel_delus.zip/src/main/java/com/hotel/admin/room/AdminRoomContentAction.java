package com.hotel.admin.room;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomInfoDTO;

public class AdminRoomContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkAdminDTO(request, response);
		
		String room_number = request.getParameter("no").trim();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		RoomInfoDTO cont = dao.getRoomContent(room_number);
		
		request.setAttribute("Cont", cont);
		
		ActionForward forward = new ActionForward();

	    forward.setPath("/WEB-INF/views/admin/room/admin_room_content.jsp");

	    return forward;
	}

}
