package com.hotel.admin.room;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.RoomDTO;

public class AdminRoomSearchAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		StaticArea.checkAdminDTO(request, response);
		
		  String field = request.getParameter("field").trim();
	      String keyword = request.getParameter("keyword").trim();
	      String name = request.getParameter("name").trim();
	      
	      System.out.println("field = " + field);
	      System.out.println("keyword = " + keyword);
	      System.out.println("name = " + name);
	      HotelTotalDAO dao = HotelTotalDAO.getInstance();
	      
	      List<RoomDTO> list = dao.SearchRoom(field, keyword, name);
	      
	      request.setAttribute("keyword", keyword);
	      request.setAttribute("field", field);
	      request.setAttribute("list", list);
	      request.setAttribute("name", name);
	      
	      ActionForward forward = new ActionForward();
	      
	      forward.setPath("/WEB-INF/views/admin/room/admin_room_list.jsp");
	         
	      return forward;
	}

}
