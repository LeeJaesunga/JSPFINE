package com.hotel.admin.room;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;

public class AdminRoomRegisterAjaxAction implements Action {

   @Override
   public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {
	   
	   StaticArea.checkAdminDTO(request, response);
	   

      // roomType 파라미터를 받아오고, 값이 없으면 기본값으로 설정
      String roomType = request.getParameter("room_type");
      if (roomType == null || roomType.isEmpty()) {
         roomType = "Delus Room_S"; // 기본값 설정
      }

      // 예시 데이터: 각 객실 타입에 대한 객실 호수 목록
      int[] roomNumbers;
      switch (roomType) {
      case "Delus Room_S":
         roomNumbers = new int[] { 201, 202, 203, 204, 205, 206, 207, 208, 209, 210, 211, 212, 213, 214, 215, 216, 217, 218, 219, 220 };
         break;
      case "Delus Room_D":
         roomNumbers = new int[] { 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 312, 313, 314, 315, 316, 317, 318, 319, 320 };
         break;
      case "Spa Delus Room":
         roomNumbers = new int[] { 401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412, 413, 414, 415, 416, 417, 418, 419, 420 };
         break;
      case "Pool Delus Room":
         roomNumbers = new int[] { 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 511, 512, 513, 514, 515, 516, 517, 518, 519, 520 };
         break;
      case "Pool Premier Room":
         roomNumbers = new int[] { 601, 602, 603, 604, 605, 606, 607, 608, 609, 610, 611, 612, 613, 614, 615 };
         break;
      case "Spa Premier Room":
         roomNumbers = new int[] { 701, 702, 703, 704, 705, 706, 707, 708, 709, 710, 711, 712, 713, 714, 715 };
         break;
      case "Pool Suite Room":
         roomNumbers = new int[] { 801, 802, 803, 804, 805, 806, 807, 808, 809, 810 };
         break;
      default:
         roomNumbers = new int[] {};
         break;
      }

      // JSON 배열 생성
      JSONArray jsonArray = new JSONArray();
      for (int roomNumber : roomNumbers) {
         jsonArray.add(roomNumber);
      }

   

      PrintWriter out = response.getWriter();
      
      // 공지사항 리스트를 JSON 형식으로 변환하여 클라이언트에 반환
      response.setContentType("application/json;charset=UTF-8");
      response.setCharacterEncoding("UTF-8");
      out.print(jsonArray.toJSONString());
      out.flush();

      return null; // AJAX 응답을 보내고 JSP 페이지로 포워드하지 않음
   }

}