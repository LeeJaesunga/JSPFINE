package com.hotel.board;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.EventDTO;
import com.hotel.model.HotelTotalDAO;

public class EventContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		int board_no = Integer.parseInt(request.getParameter("no").trim());
		
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		EventDTO dto = dao.getEventContent(board_no);
		
		dao.eventBoardHit(board_no);
		
		request.setAttribute("cont", dto);
	

		ActionForward forward = new ActionForward();
		
		forward.setPath("/WEB-INF/views/public/board/event_content.jsp");
		
		return forward;
	}

}
