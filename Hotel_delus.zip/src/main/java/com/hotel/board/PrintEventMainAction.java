package com.hotel.board;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.EventDTO;
import com.hotel.model.HotelTotalDAO;

public class PrintEventMainAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		List<EventDTO> list = dao.printEventMain();
		
		
		PrintWriter out = response.getWriter();
		
		if(list != null) {
			JSONArray jsonArray = new JSONArray();
			for (EventDTO event : list) {
				JSONObject jsonObject = new JSONObject();
				jsonObject.put("no", event.getEvent_board_no());
				jsonObject.put("title", event.getEvent_board_title());
				jsonObject.put("file", event.getEvent_board_file());
				String date = event.getEvent_board_update();
				if(date == null || date.isEmpty()) {
					date = event.getEvent_board_date();
				}
				jsonObject.put("date", date);
				jsonArray.add(jsonObject);
				
				
			}
			response.setContentType("application/json;charset=UTF-8");
			response.setCharacterEncoding("UTF-8");
			out.print(jsonArray.toJSONString());
		} else {
			out.println("[]");
		}
		
		out.close();
		return null;
	}

}
