package com.hotel.room;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.action.StaticArea;
import com.hotel.model.HotelTotalDAO;
import com.hotel.model.HotelUserDTO;
import com.hotel.model.PurchaseHistoryDTO;
import com.hotel.model.ReservateDTO;

public class RoomReservationOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		StaticArea.checkUserDTO(request, response);
		
		String room_type = request.getParameter("room_type").trim();
		
		ReservateDTO dto = new ReservateDTO();
		
		PurchaseHistoryDTO dto2 = new PurchaseHistoryDTO();
		
		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		HttpSession session = request.getSession();

	    HotelUserDTO cont = (HotelUserDTO) session.getAttribute("dto");
	    
	    String reservate_user_no = cont.getHotel_user_no();
	    String reservate_user_name = cont.getHotel_user_name();
	    
		int reservate_room_price = Integer.parseInt(request.getParameter("total_amount"));
		int reservate_headcount = Integer.parseInt(request.getParameter("total"));
		String check_in_date = request.getParameter("check_in_date").trim();
		String check_out_date = request.getParameter("check_out_date").trim();
		String check_in_hour = request.getParameter("check_in_time").trim();
		String check_out_hour = request.getParameter("check_out_time").trim();
		
		String room_name = dao.getRoomName(room_type);
		int reservate_room_no = dao.getRoomNum(room_name);
		String st_room_no = Integer.toString(reservate_room_no);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyMMdd-HHmmss-");
		Calendar c1 = Calendar.getInstance();
		String date = sdf.format(c1.getTime());
		
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyMMdd-mmss-");
		Calendar c2 = Calendar.getInstance();
		String date2 = sdf.format(c1.getTime());
		
		String reservate_no = date + st_room_no;
		
		LocalDate checkstartDate = LocalDate.parse(check_in_date);
        LocalDate checkendDate = LocalDate.parse(check_out_date);
        
		dto.setReservate_no(reservate_no);
		dto.setReservate_room_no(reservate_room_no);
		dto.setReservate_room_price(reservate_room_price);
		dto.setReservate_user_no(reservate_user_no);
		dto.setReservate_headcount(reservate_headcount);
		dto.setCheck_in_date(checkstartDate);
		dto.setCheck_in_hour(check_in_hour);
		dto.setCheck_out_date(checkendDate);
		dto.setCheck_out_hour(check_out_hour);
		
		String res_no = dto.getReservate_no();
		
		String purchase_no = date2 + reservate_user_no.substring(9, 13);
		
		dto2.setPurchase_no(purchase_no);
		dto2.setPurchase_user_no(reservate_user_no);
		dto2.setPurchase_room_no(reservate_room_no);
		dto2.setPurchase_room_price(reservate_room_price);
		dto2.setPurchase_reservate_no(reservate_no);
		
		int check = dao.ReservateInsert(dto);
		
		String res_date = dao.getReservate_date(res_no);
		
		int purIn = dao.InsertPurchaseHistory(dto2);
		System.out.println("purIn = " + purIn);
		
		PrintWriter out = response.getWriter();
		
		if (check > 0) {
 
			request.setAttribute("reservate_user_name", reservate_user_name);
			request.setAttribute("res_date", res_date);
			request.setAttribute("res_no", res_no);
			request.setAttribute("reservate_room_price", reservate_room_price);
			request.setAttribute("room_type", room_type);

			ActionForward forward = new ActionForward();

			forward.setPath("/WEB-INF/views/public/room/reservation_end.jsp");

			return forward;
			
		} else if(check == -1) {
			out.println("<script>");
			out.println("alert('중복된 예약이 존재합니다.')");
			out.println("history.back()");
			out.println("</script>");
		} else {
			out.println("<script>");
			out.println("alert('예약 오류')");
			out.println("history.back()");
			out.println("</script>");
		}
		
		return null;
	}
}
