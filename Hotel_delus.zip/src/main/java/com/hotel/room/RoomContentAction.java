package com.hotel.room;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hotel.action.Action;
import com.hotel.action.ActionForward;
import com.hotel.model.HotelTotalDAO;

import com.hotel.model.RoomInfoDTO;

public class RoomContentAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String room_type = request.getParameter("type").trim();

		HotelTotalDAO dao = HotelTotalDAO.getInstance();
		
		RoomInfoDTO cont = dao.RoomContent(room_type);
		
		request.setAttribute("Cont", cont);
		

		ActionForward forward = new ActionForward();

		forward.setPath("/WEB-INF/views/public/room/room_content.jsp");

		return forward;
	}

}
