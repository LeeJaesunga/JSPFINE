package com.hotel.model;

public class HotelUserDTO {
	
	private String hotel_user_no;
	private String hotel_user_name;
	private String hotel_user_id;
	private String hotel_user_pwd;
	private String hotel_user_phone;
	private String hotel_user_email;
	private String hotel_user_rank;
	private String hotel_user_regdate;
	private String hotel_user_payment_info;
	
	public String getHotel_user_no() {
		return hotel_user_no;
	}
	
	public void setHotel_user_no(String hotel_user_no) {
		this.hotel_user_no = hotel_user_no;
	}
	
	public String getHotel_user_name() {
		return hotel_user_name;
	}
	
	public void setHotel_user_name(String hotel_user_name) {
		this.hotel_user_name = hotel_user_name;
	}
	
	public String getHotel_user_id() {
		return hotel_user_id;
	}
	
	public void setHotel_user_id(String hotel_user_id) {
		this.hotel_user_id = hotel_user_id;
	}
	
	public String getHotel_user_pwd() {
		return hotel_user_pwd;
	}
	
	public void setHotel_user_pwd(String hotel_user_pwd) {
		this.hotel_user_pwd = hotel_user_pwd;
	}
	
	public String getHotel_user_phone() {
		return hotel_user_phone;
	}
	public void setHotel_user_phone(String hotel_user_phone) {
		this.hotel_user_phone = hotel_user_phone;
	}
	
	public String getHotel_user_email() {
		return hotel_user_email;
	}
	
	public void setHotel_user_email(String hotel_user_email) {
		this.hotel_user_email = hotel_user_email;
	}
	
	public String getHotel_user_rank() {
		return hotel_user_rank;
	}
	
	public void setHotel_user_rank(String hotel_user_rank) {
		this.hotel_user_rank = hotel_user_rank;
	}
	
	public String getHotel_user_regdate() {
		return hotel_user_regdate;
	}
	
	public void setHotel_user_regdate(String hotel_user_regdate) {
		this.hotel_user_regdate = hotel_user_regdate;
	}
	
	public String getHotel_user_payment_info() {
		return hotel_user_payment_info;
	}
	
	public void setHotel_user_payment_info(String hotel_user_payment_info) {
		this.hotel_user_payment_info = hotel_user_payment_info;
	}
	

}
