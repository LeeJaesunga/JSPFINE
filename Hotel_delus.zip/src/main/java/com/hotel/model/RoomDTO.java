package com.hotel.model;

public class RoomDTO {
	private int room_number;
	private String room_type;     
	private boolean room_reservate_status;
	private RoomInfoDTO roomInfo;
	
	public RoomInfoDTO getRoomInfo() {
		return roomInfo;
	}
	public void setRoomInfo(RoomInfoDTO roomInfo) {
		this.roomInfo = roomInfo;
	}
	public int getRoom_number() {
		return room_number;
	}
	public void setRoom_number(int room_number) {
		this.room_number = room_number;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public boolean isRoom_reservate_status() {
		return room_reservate_status;
	}
	public void setRoom_reservate_status(boolean room_reservate_status) {
		this.room_reservate_status = room_reservate_status;
	}
}
