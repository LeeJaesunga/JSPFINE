package com.hotel.model;

public class OptionDTO {

}
