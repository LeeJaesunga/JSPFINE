package com.hotel.model;

public class CountRoomDTO {
	private String room_type;
	private int count_room;
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public int getCount_room() {
		return count_room;
	}
	public void setCount_room(int count_room) {
		this.count_room = count_room;
	}
}
